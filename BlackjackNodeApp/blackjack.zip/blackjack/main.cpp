#include <iostream>
#include "game_copy.h"
using namespace std;

int main() {
	Game *game = new Game();

	// string card_name;

	// card_name = "TEN";
	// game->AddCard(card_name);
	
	// card_name = "THREE";
	// game->AddCard(card_name);

	
	// game->printCurrentHand();
	// game->printDeck();
}