#ifndef STATS_H
#define STATS_H

#include "hand.h"
#include <iostream>
using namespace std;

// namespace BJ {

// class Hand;

class Stats {
public:

	string decision;

	double win_after_hit;
	double lose_after_hit;
	double push_after_hit;

	double win;
	double lose;
	double push;

	Stats();

	// WIP
	// updates member variables based on new object instances
	void updateStats(Hand *player_hand, Deck *deck, Hand *dealer_hand);

private:

	// WIP
	double getProbDealerBust(Hand hand_in, Deck deck);

	// WIP
	double getProbWin(Hand *player_hand, Deck *deck, Hand *dealer_hand);

	// WIP
	double getProbLose(Hand *player_hand, Deck *deck, Hand *dealer_hand);

	// WIP
	double getProbPush(Hand *player_hand, Deck *deck, Hand *dealer_hand);

	// WIP
	string getDecision();	

	double getProbOfCard(Deck deck, string card_name);

	double getProbNumber(Hand hand_in, Deck deck_in, int target_num);

	void updateHandAndDeck(Hand &hand, Deck &deck, string card_name);

};

// } // namespace BJ

#endif