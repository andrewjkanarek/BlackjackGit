#ifndef DECK_H
#define DECK_H

#include "ref.h"
#include <array>
#include <unordered_map>
#include <iostream>
using namespace std;


class Card;

// namespace BJ {



class Deck {

public:

	// int card_counter[NUM_RANKS];
	array<int, NUM_RANKS> card_counter; // get rid of this

	// key: card_name (ex: "TEN")
	// value: 
	// 		key: reamaining value: # of cards with that name left in the deck
	//		key: short_name value: abreviated name of card (ex: "10")
	// NOT IMPLEMENTED YET
	std::unordered_map<std::string, int> deck_map;

	int total_cards;


	Deck();
	~Deck();

	Deck(int num_decks);

	void removeCard(Card *card); 

	void printDeck();

	
};

// } // namespace BJ

#endif