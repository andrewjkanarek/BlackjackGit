#include "deck.h"
#include "stats.h"
#include <iostream>
using namespace std;

// namespace BJ {

Stats::Stats() 
{
	decision = "HIT";
	win_after_hit = 0;
	lose_after_hit = 0;
	push_after_hit = 0;
	win = 0;
	lose = 0;
	push = 0;
}

// WIP
void Stats::updateStats(Hand *player_hand, Deck *deck, Hand *dealer_hand)
{
	// get the probability of winning without doing anything
	win = getProbWin(player_hand, deck, dealer_hand);
	// get the probability of losing without doing anything
	lose = getProbLose(player_hand, deck, dealer_hand);
	// get the probability of pushing without doing anything
	push = getProbPush(player_hand, deck, dealer_hand);
}

double Stats::getProbOfCard(Deck deck, string card_name)
{
	// probability of a card = (number of that card in the deck / number of cards in the deck)
	// assume the card has already been removed from the deck and added to the hand (add 1 to each)
	//		the probability is before it is added to the hand and removed from deck
	int total_cards = deck.total_cards + 1;
	int num = deck.deck_map[card_name] + 1;
	cout << "num: " << num << ", total: " << total_cards << "\n";
	return float(num) / total_cards;
}

// WIP
double Stats::getProbDealerBust(Hand hand_in, Deck deck_in)
{
	// cout << "entering getProbDealerBust\n";
	int total_value = hand_in.total_val;
	cout << "dealer value: " << total_value << "\n";
	// if the dealer's total is between min and max, delaer cannot hit and cannot bust
	if (total_value >= DEALER_MIN && total_value <= DEALER_MAX) 
	{
		return 0;
	}
	double prob = 0;
	// for each possible card in the deck
	for (auto it = deck_in.deck_map.begin(); it != deck_in.deck_map.end(); ++it)
	{
		cout << "current card: " << it->first << "\n";
		int remaining = it->second;
		// check if there are any left in the deck
		if (remaining > 0)
		{
			string card_name = it->first;
			Hand hand = hand_in;
			Deck deck = deck_in;
			updateHandAndDeck(hand, deck, card_name);

			// if the card causes bust, add the probability of getting that card
			if (hand.total_val > 21)
			{
				prob += getProbOfCard(deck, card_name); 
				cout << "Causes a bust. New Prob: " << prob << "\n";
				cout << "Cards left in deck: " << deck.total_cards << "\n";
			}
			// if the card doesn't cause a bust, 
			// add (probabiliy of getting that card * probability of busting with that card
			else
			{
				prob += getProbOfCard(deck, card_name) * getProbDealerBust(hand, deck);
			}

		}

	}

	return prob;
}

double Stats::getProbNumber(Hand hand_in, Deck deck_in, int target_num)
{
	if (hand_in.total_val > target_num)
	{
		return 0;
	}
	else if (hand_in.total_val < target_num)
	{
		double prob = 0;
		for (auto it = deck_in.deck_map.begin(); it != deck_in.deck_map.end(); ++it)
		{
			int remaining = it->second;
			if (remaining > 0)
			{
				string card_name = it->first;
				cout << "card: " << card_name << "\n";
				Hand hand = hand_in;
				Deck deck = deck_in;
				updateHandAndDeck(hand, deck, card_name);
				cout << "prob of card: " << getProbOfCard(deck, card_name) << "\n";
				cout << "prob number: " << getProbNumber(hand, deck, target_num) << "\n";
				prob += getProbOfCard(deck, card_name) * getProbNumber(hand, deck, target_num);
				cout << "new prob: " << prob << "\n";
			}
		}
		return prob;

	}
	else 
	{
		return 1;
	}
}

void Stats::updateHandAndDeck(Hand &hand, Deck &deck, string card_name)
{
	Card *card = new Card(card_name);
	// add the card to the current hand
	hand.addCard(card);
	// remove the card from the deck
	deck.removeCard(card);
}

// WIP
double Stats::getProbWin(Hand *player_hand, Deck *deck, Hand *dealer_hand)
{
	cout << "dealer value: " << dealer_hand->total_val << "\n";
	// return getProbDealerBust(*dealer_hand, *deck);
	deck->printDeck();
	return getProbNumber(*player_hand, *deck, 21);
}

// WIP
double Stats::getProbLose(Hand *player_hand, Deck *deck, Hand *dealer_hand)
{
	return 0;
}

// WIP
double Stats::getProbPush(Hand *player_hand, Deck *deck, Hand *dealer_hand)
{	
	return 0;
}

// WIP
string Stats::getDecision()
{
	return "HIT";
}

// } // namespace std;	
