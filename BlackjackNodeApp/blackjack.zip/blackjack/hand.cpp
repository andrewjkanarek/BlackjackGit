
#include "hand.h"
#include "stats.h"
#include "deck.h"
#include <vector>
#include <iostream>
using namespace std;

// namespace BJ {

Hand::Hand() 
{
	total_val = 0;
	has_high_ace = false;
	stats = new Stats();
};

Hand::Hand(Card *card) 
{
	total_val = 0;
	has_high_ace = false;
	addCard(card);
	stats = new Stats();
};

void Hand::addCard(Card *card) 
{
	// cout << "AddCard begin total value: " << total_val << "\n";
	// cout << "card value: " << card->getValue() << "\n";
	if (card->getName() == ACE) 
	{

		// if the ace makes the player bust, set its value to 1
		if (total_val + card->getValue() > 21) 
		{
			card->setValue(1);
		}
		else 
		{
			has_high_ace = true;
		}
		// add the card value
		total_val += card->getValue();
	}
	else 
	{
		total_val += card->getValue();
	}

	cards.push_back(card);
	// cout << "AddCard begin total value: " << total_val << "\n";
}

int Hand::getTotalValue()
{
	return total_val;
}

void Hand::printHand() {
	cout << "*** CURRENT HAND ***\n";
	cout << "total value: " << total_val << "\n";
	for (unsigned int i = 0; i < cards.size(); ++i) {
		cout << cards[i]->getName() << " ";
	}
	cout << "\n";
}

void Hand::updateStats(Deck *deck, Hand *player_hand, Hand *dealer_hand)
{
	stats->updateStats(player_hand, deck, dealer_hand);
	cout << "new prob of win: " << stats->win << "\n";
}

// } // namespace BJ
